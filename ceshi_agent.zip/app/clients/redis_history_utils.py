import json
from collections import defaultdict
from datetime import datetime
from typing import Any, Dict, List, Optional

from app.conf.redis_config import redis_config
from app.core.logger import logger

try:
    import redis
except Exception:  # pragma: no cover - optional dependency fallback
    redis = None


_redis_client = None
_memory_history: Dict[str, List[Dict[str, Any]]] = defaultdict(list)


def _session_key(session_id: str) -> str:
    return f"{redis_config.key_prefix}:history:{session_id}"


def get_redis_client():
    global _redis_client
    if _redis_client is not None:
        return _redis_client
    if not redis or not redis_config.url:
        logger.warning("Redis 未配置或 redis 依赖不可用，将使用内存会话存储")
        return None
    try:
        _redis_client = redis.Redis.from_url(redis_config.url, decode_responses=True)
        _redis_client.ping()
        logger.info("Redis 会话客户端初始化成功")
        return _redis_client
    except Exception as exc:
        logger.warning(f"Redis 连接失败，降级为内存会话存储: {exc}")
        _redis_client = None
        return None


def append_message(
    session_id: str,
    role: str,
    content: str,
    *,
    metadata: Optional[Dict[str, Any]] = None,
) -> None:
    record = {
        "role": role,
        "content": content,
        "metadata": metadata or {},
        "ts": datetime.now().isoformat(),
    }
    client = get_redis_client()
    max_messages = max(redis_config.session_window_rounds * 2, 2)

    if client is None:
        history = _memory_history[session_id]
        history.append(record)
        if len(history) > max_messages:
            _memory_history[session_id] = history[-max_messages:]
        return

    key = _session_key(session_id)
    payload = json.dumps(record, ensure_ascii=False)
    client.rpush(key, payload)
    client.ltrim(key, -max_messages, -1)
    client.expire(key, redis_config.session_ttl_seconds)


def get_recent_messages(session_id: str, limit: Optional[int] = None) -> List[Dict[str, Any]]:
    client = get_redis_client()
    if client is None:
        history = _memory_history.get(session_id, [])
        return history[-limit:] if limit else list(history)

    key = _session_key(session_id)
    raw = client.lrange(key, 0, -1)
    messages = []
    for item in raw:
        try:
            messages.append(json.loads(item))
        except json.JSONDecodeError:
            continue
    if limit:
        return messages[-limit:]
    return messages


def clear_history(session_id: str) -> int:
    client = get_redis_client()
    if client is None:
        count = len(_memory_history.get(session_id, []))
        _memory_history.pop(session_id, None)
        return count

    key = _session_key(session_id)
    count = client.llen(key)
    client.delete(key)
    return int(count)
