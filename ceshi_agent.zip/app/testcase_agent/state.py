from typing import Any, Dict, List
from typing_extensions import TypedDict


class TestCaseAgentState(TypedDict):
    session_id: str
    original_requirement: str
    is_stream: bool

    rewritten_requirement: str
    parsed_requirement: Dict[str, Any]
    chat_history: List[Dict[str, Any]]

    standards_docs: List[Dict[str, Any]]
    defect_docs: List[Dict[str, Any]]
    retrieval_summary: Dict[str, Any]

    primary_output: Dict[str, Any]
    reviewed_output: Dict[str, Any]
    final_output: Dict[str, Any]


def create_default_state(**overrides) -> TestCaseAgentState:
    state: TestCaseAgentState = {
        "session_id": "",
        "original_requirement": "",
        "is_stream": False,
        "rewritten_requirement": "",
        "parsed_requirement": {},
        "chat_history": [],
        "standards_docs": [],
        "defect_docs": [],
        "retrieval_summary": {},
        "primary_output": {},
        "reviewed_output": {},
        "final_output": {},
    }
    state.update(overrides)
    return state
