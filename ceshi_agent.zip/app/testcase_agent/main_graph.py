from langgraph.graph import END, START, StateGraph

from app.testcase_agent.nodes.node_finalize_output import node_finalize_output
from app.testcase_agent.nodes.node_generate_primary_cases import node_generate_primary_cases
from app.testcase_agent.nodes.node_intent_parse import node_intent_parse
from app.testcase_agent.nodes.node_json_guard import node_json_guard
from app.testcase_agent.nodes.node_leakage_review import node_leakage_review
from app.testcase_agent.nodes.node_search_test_knowledge import node_search_test_knowledge
from app.testcase_agent.state import TestCaseAgentState


builder = StateGraph(TestCaseAgentState)

builder.add_node("node_intent_parse", node_intent_parse)
builder.add_node("node_search_test_knowledge", node_search_test_knowledge)
builder.add_node("node_generate_primary_cases", node_generate_primary_cases)
builder.add_node("node_leakage_review", node_leakage_review)
builder.add_node("node_json_guard", node_json_guard)
builder.add_node("node_finalize_output", node_finalize_output)

builder.add_edge(START, "node_intent_parse")
builder.add_edge("node_intent_parse", "node_search_test_knowledge")
builder.add_edge("node_search_test_knowledge", "node_generate_primary_cases")
builder.add_edge("node_generate_primary_cases", "node_leakage_review")
builder.add_edge("node_leakage_review", "node_json_guard")
builder.add_edge("node_json_guard", "node_finalize_output")
builder.add_edge("node_finalize_output", END)

testcase_agent_app = builder.compile()
