from typing import List, Literal

from pydantic import BaseModel, Field


CasePriority = Literal["P0", "P1", "P2", "P3"]
CaseType = Literal["positive", "negative", "boundary", "exception"]


class TestStep(BaseModel):
    step_no: int = Field(..., ge=1)
    action: str = Field(..., min_length=1)
    expected_result: str = Field(..., min_length=1)


class TestCaseItem(BaseModel):
    case_id: str = Field(..., min_length=1)
    title: str = Field(..., min_length=1)
    objective: str = Field(..., min_length=1)
    preconditions: List[str] = Field(default_factory=list)
    test_data: List[str] = Field(default_factory=list)
    steps: List[TestStep] = Field(default_factory=list, min_length=1)
    priority: CasePriority
    case_type: CaseType
    coverage_tags: List[str] = Field(default_factory=list)
    risk_source: str = Field(default="")


class SelfReflection(BaseModel):
    coverage_gaps_checked: List[str] = Field(default_factory=list)
    supplement_strategy: List[str] = Field(default_factory=list)
    linked_defect_patterns: List[str] = Field(default_factory=list)
    confidence: str = Field(default="")


class TestCaseAgentResponse(BaseModel):
    requirement_summary: str = Field(..., min_length=1)
    rewritten_requirement: str = Field(..., min_length=1)
    standardized_cases: List[TestCaseItem] = Field(default_factory=list)
    missing_risk_scenarios: List[str] = Field(default_factory=list)
    review_checklist: List[str] = Field(default_factory=list)
    self_reflection: SelfReflection
