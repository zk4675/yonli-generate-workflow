import json
import sys
from typing import Any, Dict

from app.core.load_prompt import load_prompt
from app.core.logger import logger
from app.lm.lm_utils import get_llm_client
from app.testcase_agent.schemas import TestCaseAgentResponse
from app.utils.task_utils import add_done_task, add_running_task


def _normalize_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
    payload.setdefault("requirement_summary", "未提供摘要")
    payload.setdefault("rewritten_requirement", payload.get("requirement_summary", ""))
    payload.setdefault("standardized_cases", [])
    payload.setdefault("missing_risk_scenarios", [])
    payload.setdefault("review_checklist", [])
    payload.setdefault(
        "self_reflection",
        {
            "coverage_gaps_checked": [],
            "supplement_strategy": [],
            "linked_defect_patterns": [],
            "confidence": "normalized",
        },
    )
    return payload


def node_json_guard(state):
    logger.info("---node_json_guard 开始处理---")
    session_id = state["session_id"]
    is_stream = state.get("is_stream", False)
    add_running_task(session_id, sys._getframe().f_code.co_name, is_stream)

    payload = _normalize_payload(dict(state.get("reviewed_output") or {}))

    try:
        validated = TestCaseAgentResponse.model_validate(payload)
    except Exception as exc:
        logger.warning(f"JSON 校验首轮失败，尝试调用修复 Prompt: {exc}")
        try:
            prompt = load_prompt("testcase_json_repair", broken_json=json.dumps(payload, ensure_ascii=False, indent=2))
            llm = get_llm_client(json_mode=True)
            response = llm.invoke(prompt)
            repaired = json.loads(response.content)
            validated = TestCaseAgentResponse.model_validate(_normalize_payload(repaired))
        except Exception as repair_exc:
            logger.warning(f"JSON 修复失败，执行本地兜底收敛: {repair_exc}")
            validated = TestCaseAgentResponse.model_validate(_normalize_payload(payload))

    add_done_task(session_id, sys._getframe().f_code.co_name, is_stream)
    return {"final_output": validated.model_dump()}
