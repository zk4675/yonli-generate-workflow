import json
import sys
from typing import Any, Dict, List

from app.core.load_prompt import load_prompt
from app.core.logger import logger
from app.lm.lm_utils import get_llm_client
from app.utils.task_utils import add_done_task, add_running_task


def _fallback_cases(parsed_requirement: Dict[str, Any], standards_docs: List[Dict[str, Any]]) -> Dict[str, Any]:
    summary = parsed_requirement.get("requirement_summary") or parsed_requirement.get("business_goal") or "测试需求"
    tags = parsed_requirement.get("risk_keywords") or ["主流程", "边界输入", "异常处理"]
    base_cases = [
        {
            "case_id": "TC-P0-001",
            "title": f"{summary}-主流程验证",
            "objective": "验证核心业务链路可正常闭环执行",
            "preconditions": ["测试环境可用", "账号具备必要权限"],
            "test_data": ["标准合法输入"],
            "steps": [
                {"step_no": 1, "action": "进入功能入口并填写合法数据", "expected_result": "页面展示正常"},
                {"step_no": 2, "action": "提交主流程操作", "expected_result": "操作成功并返回预期结果"},
            ],
            "priority": "P0",
            "case_type": "positive",
            "coverage_tags": ["主流程", *tags[:2]],
            "risk_source": "primary-generation",
        },
        {
            "case_id": "TC-P1-002",
            "title": f"{summary}-边界与校验",
            "objective": "验证关键输入边界和必填校验",
            "preconditions": ["测试环境可用"],
            "test_data": ["空值", "超长值", "特殊字符"],
            "steps": [
                {"step_no": 1, "action": "分别输入空值、超长值和特殊字符", "expected_result": "页面给出明确校验提示"},
                {"step_no": 2, "action": "修正输入后再次提交", "expected_result": "系统允许继续流程"},
            ],
            "priority": "P1",
            "case_type": "boundary",
            "coverage_tags": ["边界", "校验", *tags[:2]],
            "risk_source": "primary-generation",
        },
    ]
    return {
        "requirement_summary": summary,
        "rewritten_requirement": parsed_requirement.get("business_goal", summary),
        "standardized_cases": base_cases,
        "missing_risk_scenarios": [doc.get("title", "") for doc in standards_docs[:2]],
        "review_checklist": ["步骤与预期一一对应", "P0/P1 已覆盖主流程和边界"],
        "self_reflection": {
            "coverage_gaps_checked": ["空值", "边界值", "权限"],
            "supplement_strategy": ["后续结合历史缺陷补异常场景"],
            "linked_defect_patterns": [],
            "confidence": "fallback",
        },
    }


def node_generate_primary_cases(state):
    logger.info("---node_generate_primary_cases 开始处理---")
    session_id = state["session_id"]
    is_stream = state.get("is_stream", False)
    add_running_task(session_id, sys._getframe().f_code.co_name, is_stream)

    parsed_requirement = state.get("parsed_requirement") or {}
    standards_docs = state.get("standards_docs") or []
    output = _fallback_cases(parsed_requirement, standards_docs)

    try:
        prompt = load_prompt(
            "testcase_primary_generation",
            parsed_requirement=json.dumps(parsed_requirement, ensure_ascii=False, indent=2),
            standards_docs=json.dumps(standards_docs, ensure_ascii=False, indent=2),
        )
        llm = get_llm_client(json_mode=True)
        response = llm.invoke(prompt)
        payload = json.loads(response.content)
        if payload:
            output.update(payload)
    except Exception as exc:
        logger.warning(f"首轮用例生成失败，使用规则模板降级: {exc}")

    add_done_task(session_id, sys._getframe().f_code.co_name, is_stream)
    return {"primary_output": output}
