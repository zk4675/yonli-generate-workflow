import json
import sys

from app.clients.redis_history_utils import append_message
from app.core.logger import logger
from app.utils.sse_utils import SSEEvent, push_to_session
from app.utils.task_utils import add_done_task, add_running_task, set_task_result


def _to_markdown(result: dict) -> str:
    lines = [
        f"# 测试方案摘要\n{result.get('requirement_summary', '')}",
        "",
        "## 标准化测试用例",
    ]
    for case in result.get("standardized_cases", []):
        lines.append(f"### {case.get('case_id')} {case.get('title')}")
        lines.append(f"- 优先级: {case.get('priority')}")
        lines.append(f"- 类型: {case.get('case_type')}")
        lines.append(f"- 目标: {case.get('objective')}")
        lines.append(f"- 标签: {', '.join(case.get('coverage_tags', []))}")
    lines.append("")
    lines.append("## 防漏测检查")
    for item in result.get("review_checklist", []):
        lines.append(f"- {item}")
    return "\n".join(lines)


def node_finalize_output(state):
    logger.info("---node_finalize_output 开始处理---")
    session_id = state["session_id"]
    is_stream = state.get("is_stream", False)
    add_running_task(session_id, sys._getframe().f_code.co_name, is_stream)

    result = state.get("final_output") or {}
    result_text = json.dumps(result, ensure_ascii=False, indent=2)
    markdown = _to_markdown(result)

    set_task_result(session_id, "result_json", result_text)
    set_task_result(session_id, "result_markdown", markdown)

    append_message(
        session_id,
        "user",
        state.get("original_requirement", ""),
        metadata={"rewritten_requirement": state.get("rewritten_requirement", "")},
    )
    append_message(
        session_id,
        "assistant",
        markdown,
        metadata={"result_json": result},
    )

    if is_stream:
        push_to_session(session_id, SSEEvent.FINAL, {"status": "completed", "result": result, "markdown": markdown})

    add_done_task(session_id, sys._getframe().f_code.co_name, is_stream)
    return {"final_output": result}
