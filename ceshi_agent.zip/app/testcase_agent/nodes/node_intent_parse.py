import json
import re
import sys
from typing import Any, Dict, List

from app.clients.redis_history_utils import get_recent_messages
from app.core.load_prompt import load_prompt
from app.core.logger import logger
from app.lm.lm_utils import get_llm_client
from app.utils.task_utils import add_done_task, add_running_task


def _local_parse(requirement: str, history: List[Dict[str, Any]]) -> Dict[str, Any]:
    lines = [line.strip() for line in requirement.splitlines() if line.strip()]
    summary = lines[0] if lines else requirement[:80]
    risks = []
    keywords = ["权限", "支付", "导出", "批量", "并发", "审批", "删除", "回滚", "登录", "上传"]
    for word in keywords:
        if word in requirement:
            risks.append(word)
    if not risks:
        risks = ["主流程", "边界输入", "异常处理"]
    return {
        "requirement_summary": summary,
        "business_goal": summary,
        "core_entities": re.findall(r"[A-Za-z0-9_\-\u4e00-\u9fa5]{2,}", summary)[:6],
        "risk_keywords": list(dict.fromkeys(risks)),
        "priority_focus": "P0/P1",
        "history_context": [f"{m.get('role')}: {m.get('content')}" for m in history[-6:]],
    }


def node_intent_parse(state):
    logger.info("---node_intent_parse 开始处理---")
    session_id = state["session_id"]
    is_stream = state.get("is_stream", False)
    add_running_task(session_id, sys._getframe().f_code.co_name, is_stream)

    requirement = state.get("original_requirement", "").strip()
    history = get_recent_messages(session_id, limit=20)

    parsed = _local_parse(requirement, history)
    rewritten_requirement = requirement

    try:
        prompt = load_prompt(
            "testcase_intent_parse",
            requirement=requirement,
            history=json.dumps(history[-10:], ensure_ascii=False, indent=2),
        )
        llm = get_llm_client(json_mode=True)
        response = llm.invoke(prompt)
        payload = json.loads(response.content)
        parsed.update(payload)
        rewritten_requirement = payload.get("rewritten_requirement", requirement) or requirement
    except Exception as exc:
        logger.warning(f"意图解析调用 LLM 失败，使用本地规则降级: {exc}")

    add_done_task(session_id, sys._getframe().f_code.co_name, is_stream)
    return {
        "chat_history": history,
        "parsed_requirement": parsed,
        "rewritten_requirement": rewritten_requirement,
    }
