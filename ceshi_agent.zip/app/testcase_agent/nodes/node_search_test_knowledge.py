import os
import sys
from typing import Dict, List

from app.core.logger import logger
from app.testcase_agent.knowledge_seed import DEFECT_KNOWLEDGE, STANDARD_KNOWLEDGE
from app.utils.task_utils import add_done_task, add_running_task


def _seed_search(query: str, docs: List[Dict], topk: int) -> List[Dict]:
    ranked = []
    for doc in docs:
        score = sum(1 for tag in doc.get("tags", []) if tag and tag in query)
        ranked.append({**doc, "score": score})
    ranked.sort(key=lambda item: item["score"], reverse=True)
    return ranked[:topk]


def _milvus_search(query: str, collection_name: str, topk: int = 5) -> List[Dict]:
    if not collection_name:
        return []
    try:
        from app.clients.milvus_utils import create_hybrid_search_requests, get_milvus_client, hybrid_search
        from app.lm.embedding_utils import generate_embeddings
    except Exception as exc:
        logger.warning(f"Milvus/BGE 依赖不可用，跳过向量检索: {exc}")
        return []
    client = get_milvus_client()
    if client is None:
        return []
    embeddings = generate_embeddings([query])
    reqs = create_hybrid_search_requests(
        dense_vector=embeddings["dense"][0],
        sparse_vector=embeddings["sparse"][0],
        limit=topk,
    )
    result = hybrid_search(
        client=client,
        collection_name=collection_name,
        reqs=reqs,
        ranker_weights=(0.8, 0.2),
        norm_score=True,
        limit=topk,
        output_fields=["chunk_id", "content", "title", "item_name"],
    )
    docs = []
    for hit in (result[0] if result else []):
        entity = hit.get("entity") if isinstance(hit, dict) else {}
        docs.append(
            {
                "title": entity.get("title") or entity.get("item_name") or "Milvus Doc",
                "text": entity.get("content", ""),
                "chunk_id": entity.get("chunk_id"),
                "score": hit.get("distance", 0.0) if isinstance(hit, dict) else 0.0,
            }
        )
    return docs


def node_search_test_knowledge(state):
    logger.info("---node_search_test_knowledge 开始处理---")
    session_id = state["session_id"]
    is_stream = state.get("is_stream", False)
    add_running_task(session_id, sys._getframe().f_code.co_name, is_stream)

    query = state.get("rewritten_requirement") or state.get("original_requirement") or ""
    standards_collection = os.getenv("TESTCASE_STANDARDS_COLLECTION", "")
    defects_collection = os.getenv("TESTCASE_DEFECTS_COLLECTION", "")

    standards_docs = _milvus_search(query, standards_collection, topk=5)
    defect_docs = _milvus_search(query, defects_collection, topk=5)

    if not standards_docs:
        logger.info("标准知识库检索为空，使用内置测试标准种子")
        standards_docs = _seed_search(query, STANDARD_KNOWLEDGE, 5)
    if not defect_docs:
        logger.info("缺陷知识库检索为空，使用内置历史缺陷种子")
        defect_docs = _seed_search(query, DEFECT_KNOWLEDGE, 5)

    summary = {
        "standards_hit_count": len(standards_docs),
        "defects_hit_count": len(defect_docs),
        "cross_check_mode": "vector+fallback",
    }

    add_done_task(session_id, sys._getframe().f_code.co_name, is_stream)
    return {
        "standards_docs": standards_docs,
        "defect_docs": defect_docs,
        "retrieval_summary": summary,
    }
