import json
import sys
from typing import Any, Dict, List

from app.core.load_prompt import load_prompt
from app.core.logger import logger
from app.lm.lm_utils import get_llm_client
from app.utils.task_utils import add_done_task, add_running_task


def _merge_with_defects(primary_output: Dict[str, Any], defect_docs: List[Dict[str, Any]]) -> Dict[str, Any]:
    reviewed = json.loads(json.dumps(primary_output, ensure_ascii=False))
    reviewed.setdefault("missing_risk_scenarios", [])
    reviewed.setdefault("review_checklist", [])
    reflection = reviewed.setdefault(
        "self_reflection",
        {
            "coverage_gaps_checked": [],
            "supplement_strategy": [],
            "linked_defect_patterns": [],
            "confidence": "fallback",
        },
    )

    supplement_cases = []
    next_index = len(reviewed.get("standardized_cases", [])) + 1
    for doc in defect_docs[:3]:
        title = doc.get("title", "历史缺陷")
        text = doc.get("text", "")
        reviewed["missing_risk_scenarios"].append(title)
        reviewed["review_checklist"].append(f"已补充历史缺陷发散检查: {title}")
        reflection["coverage_gaps_checked"].append(title)
        reflection["linked_defect_patterns"].append(title)
        reflection["supplement_strategy"].append(f"基于缺陷模式补充异常用例: {title}")
        supplement_cases.append(
            {
                "case_id": f"TC-P1-{next_index:03d}",
                "title": f"{title}-异常补全",
                "objective": f"验证历史缺陷模式不会再次出现: {title}",
                "preconditions": ["功能已具备基础数据", "已打开关键操作入口"],
                "test_data": ["异常输入", "重复请求", "权限切换"],
                "steps": [
                    {"step_no": 1, "action": f"构造与缺陷模式相关的操作: {title}", "expected_result": "系统进入受控处理流程"},
                    {"step_no": 2, "action": "检查提示、状态回滚和幂等结果", "expected_result": text or "系统不应出现数据错乱或重复执行"},
                ],
                "priority": "P1",
                "case_type": "exception",
                "coverage_tags": ["历史缺陷", "防漏测", "异常场景"],
                "risk_source": title,
            }
        )
        next_index += 1

    reviewed["standardized_cases"] = reviewed.get("standardized_cases", []) + supplement_cases
    return reviewed


def node_leakage_review(state):
    logger.info("---node_leakage_review 开始处理---")
    session_id = state["session_id"]
    is_stream = state.get("is_stream", False)
    add_running_task(session_id, sys._getframe().f_code.co_name, is_stream)

    primary_output = state.get("primary_output") or {}
    defect_docs = state.get("defect_docs") or []
    reviewed = _merge_with_defects(primary_output, defect_docs)

    try:
        prompt = load_prompt(
            "testcase_leakage_review",
            primary_output=json.dumps(primary_output, ensure_ascii=False, indent=2),
            defect_docs=json.dumps(defect_docs, ensure_ascii=False, indent=2),
        )
        llm = get_llm_client(json_mode=True)
        response = llm.invoke(prompt)
        payload = json.loads(response.content)
        if payload:
            reviewed.update(payload)
    except Exception as exc:
        logger.warning(f"二次反思补全失败，保留本地防漏测合并结果: {exc}")

    add_done_task(session_id, sys._getframe().f_code.co_name, is_stream)
    return {"reviewed_output": reviewed}
