import json
from pathlib import Path
from typing import Any, Dict, List

from app.core.logger import logger
from app.utils.path_util import PROJECT_ROOT


KNOWLEDGE_DIR = PROJECT_ROOT / "doc" / "knowledge_base"
STANDARDS_FILE = KNOWLEDGE_DIR / "testcase_standards.json"
DEFECTS_FILE = KNOWLEDGE_DIR / "historical_defects.json"


DEFAULT_STANDARD_KNOWLEDGE = [
    {
        "title": "P0/P1 优先级判定标准",
        "text": "P0 关注核心链路不可用、资金或数据错误、阻断发布。P1 关注主要功能异常、权限绕过、状态流转和兼容性问题。",
        "tags": ["P0", "P1", "优先级", "核心链路", "权限", "状态流转", "资金", "数据"],
    },
    {
        "title": "测试用例标准化字段要求",
        "text": "每条用例都应包含目标、前置条件、测试数据、步骤、预期结果、优先级、类型、覆盖标签和风险来源。",
        "tags": ["标准化", "前置条件", "测试数据", "步骤", "预期结果", "标签"],
    },
    {
        "title": "边界值与异常校验策略",
        "text": "除主流程外，必须检查空值、超长、非法字符、重复提交、并发、时间边界、网络中断、权限切换和幂等性。",
        "tags": ["空值", "超长", "非法字符", "重复提交", "并发", "网络异常", "权限切换", "幂等"],
    },
    {
        "title": "状态机类需求测试方法",
        "text": "涉及审批、订单、任务或工单状态流转时，应覆盖正向流转、逆向回退、重复操作、非法状态跳转和跨角色操作。",
        "tags": ["状态流转", "审批", "订单", "回退", "非法跳转", "跨角色"],
    },
    {
        "title": "防漏测审查清单",
        "text": "生成首轮用例后，需要审查是否覆盖角色、入口、数据量、边界值、异常提示、回滚、一致性、幂等、日志与通知。",
        "tags": ["审查清单", "角色", "入口", "数据量", "回滚", "一致性", "日志", "通知"],
    },
]


DEFAULT_DEFECT_KNOWLEDGE = [
    {
        "title": "历史缺陷: 重复点击导致重复创建",
        "text": "提交按钮未及时置灰时，用户多次点击导致重复下单、重复发起审批或重复创建记录，需要验证接口幂等和前端防抖。",
        "tags": ["重复提交", "幂等", "按钮防抖", "审批", "创建"],
    },
    {
        "title": "历史缺陷: 权限缓存未刷新",
        "text": "角色切换后缓存未清理，低权限用户仍能访问高权限页面或继续执行操作，需要覆盖刷新、重新登录和多端切换。",
        "tags": ["权限", "缓存", "角色切换", "多端", "刷新"],
    },
    {
        "title": "历史缺陷: 时间边界计算错误",
        "text": "跨天、月底、闰年或时区切换时，截止时间、有效期和定时任务执行窗口计算错误，需要覆盖 00:00、月底和时区偏移。",
        "tags": ["时间边界", "跨天", "月底", "闰年", "时区", "有效期"],
    },
    {
        "title": "历史缺陷: 状态回滚不完整",
        "text": "异常发生后只回滚主表，未同步回滚明细、缓存或通知记录，导致前后状态不一致，需要验证事务回滚和补偿逻辑。",
        "tags": ["回滚", "事务", "缓存一致性", "通知", "状态不一致"],
    },
    {
        "title": "历史缺陷: 并发审批导致状态覆盖",
        "text": "两个审批人并发处理同一单据时，后写覆盖前写，导致最终状态错误，需要验证乐观锁、重复审批拦截和审计日志。",
        "tags": ["并发", "审批", "状态覆盖", "乐观锁", "审计日志"],
    },
]


def _load_json_file(path: Path, fallback: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    try:
        if not path.exists():
            logger.info(f"知识库文件不存在，使用默认内置数据: {path}")
            return fallback
        payload = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(payload, list) and payload:
            return payload
        logger.warning(f"知识库文件为空或格式异常，使用默认内置数据: {path}")
        return fallback
    except Exception as exc:
        logger.warning(f"加载知识库文件失败，使用默认内置数据: {path}, error={exc}")
        return fallback


def load_standard_knowledge() -> List[Dict[str, Any]]:
    return _load_json_file(STANDARDS_FILE, DEFAULT_STANDARD_KNOWLEDGE)


def load_defect_knowledge() -> List[Dict[str, Any]]:
    return _load_json_file(DEFECTS_FILE, DEFAULT_DEFECT_KNOWLEDGE)


STANDARD_KNOWLEDGE = load_standard_knowledge()
DEFECT_KNOWLEDGE = load_defect_knowledge()
