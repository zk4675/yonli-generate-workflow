from dataclasses import dataclass
import os
from dotenv import load_dotenv

load_dotenv()


@dataclass
class RedisConfig:
    url: str
    key_prefix: str
    session_ttl_seconds: int
    session_window_rounds: int


redis_config = RedisConfig(
    url=os.getenv("REDIS_URL", ""),
    key_prefix=os.getenv("REDIS_KEY_PREFIX", "testcase-agent"),
    session_ttl_seconds=int(os.getenv("REDIS_SESSION_TTL_SECONDS", "3600")),
    session_window_rounds=int(os.getenv("REDIS_SESSION_WINDOW_ROUNDS", "10")),
)
