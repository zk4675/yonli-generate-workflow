import uuid
from pathlib import Path

from fastapi import BackgroundTasks, FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, StreamingResponse
from pydantic import BaseModel, Field, model_validator
from starlette.middleware.cors import CORSMiddleware

from app.clients.redis_history_utils import clear_history, get_recent_messages
from app.testcase_agent.main_graph import testcase_agent_app
from app.testcase_agent.state import create_default_state
from app.utils.sse_utils import SSEEvent, create_sse_queue, sse_generator
from app.utils.task_utils import (
    TASK_STATUS_COMPLETED,
    TASK_STATUS_FAILED,
    TASK_STATUS_PROCESSING,
    get_task_result,
    update_task_status,
)


app = FastAPI(
    title="Test Case Standardization Agent",
    description="针对测试工程师的用例标准化与防漏测智能体服务",
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
async def home():
    return await chat()


@app.get("/chat.html")
async def chat():
    current_dir_parent_path = Path(__file__).absolute().parent.parent
    chat_html_path = current_dir_parent_path / "page" / "chat.html"
    if not chat_html_path.exists():
        raise HTTPException(status_code=404, detail=f"页面不存在：{chat_html_path}")
    return FileResponse(chat_html_path)


class TestCaseGenerateRequest(BaseModel):
    requirement: str | None = Field(default=None, description="测试需求、业务说明或用户故事")
    query: str | None = Field(default=None, description="兼容旧字段，等同于 requirement")
    session_id: str | None = Field(default=None, description="会话ID")
    is_stream: bool = Field(default=False, description="是否使用流式返回")

    @model_validator(mode="after")
    def ensure_requirement(self):
        self.requirement = (self.requirement or self.query or "").strip()
        if not self.requirement:
            raise ValueError("requirement 不能为空")
        return self


@app.get("/health")
async def health():
    return {"ok": True, "agent": "testcase-standardization"}


def run_testcase_graph(session_id: str, requirement: str, is_stream: bool = True):
    default_state = create_default_state(
        session_id=session_id,
        original_requirement=requirement,
        is_stream=is_stream,
    )
    try:
        testcase_agent_app.invoke(default_state)
        update_task_status(session_id, TASK_STATUS_COMPLETED, is_stream)
    except Exception as exc:
        update_task_status(session_id, TASK_STATUS_FAILED, is_stream)
        if is_stream:
            from app.utils.sse_utils import push_to_session

            push_to_session(session_id, SSEEvent.ERROR, {"error": str(exc)})
        raise


@app.post("/testcase/generate")
@app.post("/query")
async def generate_testcases(background_tasks: BackgroundTasks, request: TestCaseGenerateRequest):
    requirement = request.requirement or ""
    session_id = request.session_id or str(uuid.uuid4())
    is_stream = request.is_stream

    if is_stream:
        create_sse_queue(session_id)
    update_task_status(session_id, TASK_STATUS_PROCESSING, is_stream)

    if is_stream:
        background_tasks.add_task(run_testcase_graph, session_id, requirement, is_stream)
        return {
            "message": "测试用例正在生成中",
            "session_id": session_id,
            "mode": "stream",
        }

    run_testcase_graph(session_id, requirement, is_stream)
    return {
        "message": "测试用例生成完成",
        "session_id": session_id,
        "result_json": get_task_result(session_id, "result_json", ""),
        "result_markdown": get_task_result(session_id, "result_markdown", ""),
    }


@app.get("/stream/{session_id}")
async def stream(session_id: str, request: Request):
    return StreamingResponse(
        sse_generator(session_id, request),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


@app.get("/history/{session_id}")
async def history(session_id: str, limit: int = 20):
    return {"session_id": session_id, "items": get_recent_messages(session_id, limit=limit)}


@app.delete("/history/{session_id}")
async def clear_chat_history(session_id: str):
    count = clear_history(session_id)
    return {"message": "History cleared", "deleted_count": count}


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="127.0.0.1", port=8001)
