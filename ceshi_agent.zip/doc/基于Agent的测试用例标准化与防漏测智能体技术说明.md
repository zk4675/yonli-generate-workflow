# 基于Agent的测试用例标准化与防漏测智能体技术说明

## 1. 项目定位

本项目在原有“文档导入 + 检索问答”工程基础上，升级为面向测试工程师的测试辅助智能体。目标是围绕“测试用例编写耗时、规范不统一、边界场景易漏测”的痛点，提供一条可复用、可审计、可追溯的自动生成链路。

升级后的系统名称为：**基于Agent的测试用例标准化与防漏测智能体**。

核心价值：

- 自动解析业务需求，提取测试范围、关键实体、风险关键词。
- 联动测试规范库和历史缺陷库，形成双步交叉验证。
- 输出严格 JSON 结构的标准化测试方案，便于后续接平台或导出。
- 在主流程用例生成后自动做二次反思，补齐异常、边界和历史高风险场景。
- 通过 Redis 管理多轮会话，控制上下文窗口，减少长文本失忆与内存膨胀。

## 2. 目录与主要改造点

本次新增与改造的核心文件如下：

- `app/testcase_agent/`
  - 新增测试用例智能体业务包。
- `app/clients/redis_history_utils.py`
  - 新增 Redis 多轮会话与 TTL 封装。
- `app/conf/redis_config.py`
  - 新增 Redis 配置。
- `app/query_process/api/query_service.py`
  - 改造为新的测试用例生成服务入口。
- `prompts/testcase_*.prompt`
  - 新增意图解析、首轮生成、二次反思、JSON 修复 Prompt。
- `test/06-testcase-agent-schema.py`
  - 新增 JSON 结构校验冒烟脚本。
- `test/07-redis-history-fallback.py`
  - 新增 Redis 降级会话冒烟脚本。

## 3. 总体架构

### 3.1 链路分层

系统分为四层：

1. 接口层
   - FastAPI 对外提供 `/testcase/generate`、`/stream/{session_id}`、`/history/{session_id}` 等接口。
2. Agent 编排层
   - 使用 LangGraph 将需求解析、知识检索、首轮生成、二次反思、JSON 校验、最终落库串成状态图。
3. 检索与会话层
   - 使用 Milvus 检索测试规范知识与历史缺陷知识。
   - 使用 Redis 管理多轮会话、10 轮滑动窗口和 TTL 清理。
4. 生成与约束层
   - 使用大模型 JSON 模式完成结构化输出。
   - 使用 Pydantic 做严格格式校验，必要时触发 JSON 修复 Prompt。

### 3.2 Agent 流程

升级后的主图定义在 `app/testcase_agent/main_graph.py`，执行顺序如下：

1. `node_intent_parse`
2. `node_search_test_knowledge`
3. `node_generate_primary_cases`
4. `node_leakage_review`
5. `node_json_guard`
6. `node_finalize_output`

这条链路对应业务含义：

1. 先理解需求。
2. 再拉取测试规范与历史缺陷。
3. 先生成正向主流程与基础边界用例。
4. 再根据历史缺陷做防漏测补全。
5. 最后强制落到标准 JSON。

## 4. 各模块实现技术与步骤

### 4.1 需求意图解析

实现文件：`app/testcase_agent/nodes/node_intent_parse.py`

实现目标：

- 接收测试需求、用户故事、业务变更说明。
- 提取业务目标、核心实体、风险关键词、P0/P1 关注点。
- 生成 `rewritten_requirement`，让后续检索和生成依赖更稳定的独立描述。

实现步骤：

1. 读取当前会话的最近历史。
2. 用本地规则先给出一个兜底解析结果。
3. 调用 `prompts/testcase_intent_parse.prompt` 让模型输出严格 JSON。
4. 若模型失败，则回退到本地规则。

实现技术：

- LangGraph 节点编排
- LangChain `ChatOpenAI`
- JSON Mode
- Redis 会话历史注入

### 4.2 双步交叉验证检索

实现文件：`app/testcase_agent/nodes/node_search_test_knowledge.py`

实现目标：

- 同时检索两类知识：
  - 测试规范与高频易错规则
  - 历史缺陷与异常场景模式
- 为首轮生成和二次反思提供不同视角的外部知识。

实现步骤：

1. 使用 BGE-M3 对改写后的需求做稠密+稀疏向量化。
2. 若配置了 Milvus 集合：
   - 从 `TESTCASE_STANDARDS_COLLECTION` 检索规范。
   - 从 `TESTCASE_DEFECTS_COLLECTION` 检索历史缺陷。
3. 若 Milvus 不可用，则自动回退到内置知识种子。
4. 输出 `standards_docs`、`defect_docs` 和 `retrieval_summary`。

实现技术：

- BGE-M3 混合向量
- Milvus Hybrid Search
- 向量知识库
- 本地规则种子兜底

### 4.3 首轮标准化测试用例生成

实现文件：`app/testcase_agent/nodes/node_generate_primary_cases.py`

实现目标：

- 根据解析结果和规范知识生成标准化测试用例。
- 首轮只聚焦正向主流程、核心校验、边界输入。

实现步骤：

1. 将解析结果和测试规范组装进 `testcase_primary_generation.prompt`。
2. 强制模型仅输出 JSON。
3. 使用统一的字段规范生成测试用例。
4. 若模型失败，则退回本地模板用例。

用例标准字段：

- `case_id`
- `title`
- `objective`
- `preconditions`
- `test_data`
- `steps`
- `priority`
- `case_type`
- `coverage_tags`
- `risk_source`

实现技术：

- Prompt Engineering
- 严格 JSON 输出
- 模板化兜底

### 4.4 防漏测机制与二次反思

实现文件：`app/testcase_agent/nodes/node_leakage_review.py`

这是本次升级最关键的能力。

实现目标：

- 在主流程用例生成后，利用历史缺陷知识自动补充异常与边界场景。
- 强制输出 `self_reflection` 字段代替单步裸生成，减少模型盲目性。

实现步骤：

1. 读取首轮生成结果 `primary_output`。
2. 读取历史缺陷文档 `defect_docs`。
3. 先执行本地合并逻辑：
   - 为每条缺陷模式生成对应的异常用例。
   - 自动补充到 `standardized_cases`。
   - 同时更新 `missing_risk_scenarios` 和 `review_checklist`。
4. 再调用 `testcase_leakage_review.prompt` 做二次反思，让模型显式输出：
   - 已检查的漏测点
   - 补充策略
   - 关联缺陷模式
   - 信心说明

这部分就是“**双步交叉验证与反思机制**”的核心落地：

- 第一步：标准规范约束首轮主流程生成。
- 第二步：历史缺陷反向发散异常场景补全。

实现技术：

- 双阶段 Prompt
- Retrieval-Augmented Generation
- Self-Reflection 字段化输出

### 4.5 严格 JSON 格式约束

实现文件：

- `app/testcase_agent/schemas.py`
- `app/testcase_agent/nodes/node_json_guard.py`

实现目标：

- 把大模型输出变成“可校验、可消费、可落平台”的结构化对象。
- 降低幻觉字段、漏字段、类型错误。

实现步骤：

1. 定义 Pydantic 数据结构：
   - `TestStep`
   - `TestCaseItem`
   - `SelfReflection`
   - `TestCaseAgentResponse`
2. 对二次反思结果执行 `model_validate`。
3. 若校验失败：
   - 触发 `testcase_json_repair.prompt` 让模型修复 JSON。
4. 若仍失败：
   - 使用本地归一化逻辑补齐关键字段并再次校验。

实现技术：

- Pydantic 强类型模型
- JSON Repair Prompt
- 本地 Normalize 兜底

### 4.6 Redis 多轮对话管理

实现文件：

- `app/conf/redis_config.py`
- `app/clients/redis_history_utils.py`

实现目标：

- 支撑多轮会话。
- 使用 10 轮滑动窗口控制上下文长度。
- 使用 TTL 避免历史无限堆积。

实现步骤：

1. 从环境变量读取：
   - `REDIS_URL`
   - `REDIS_KEY_PREFIX`
   - `REDIS_SESSION_TTL_SECONDS`
   - `REDIS_SESSION_WINDOW_ROUNDS`
2. 每次消息写入时：
   - 使用 Redis `RPUSH` 追加消息。
   - 使用 `LTRIM` 保留最近 `10 * 2` 条消息。
   - 使用 `EXPIRE` 设置 TTL。
3. 若 Redis 不可用，则自动回退到内存态。

为什么是 `10 * 2`：

- 10 轮对话通常意味着“用户消息 + 助手消息”配对存储。
- 所以最大消息条数默认保留 20 条。

实现技术：

- Redis List
- TTL
- 滑动窗口
- 内存降级容灾

### 4.7 服务接口层

实现文件：`app/query_process/api/query_service.py`

当前接口：

- `POST /testcase/generate`
  - 输入测试需求
  - 输出 JSON 结果和 Markdown 结果
- `POST /query`
  - 兼容旧入口，功能同上
- `GET /stream/{session_id}`
  - 流式返回生成进度与最终结果
- `GET /history/{session_id}`
  - 查询 Redis 会话历史
- `DELETE /history/{session_id}`
  - 清空会话

请求体：

```json
{
  "requirement": "审批流程新增撤回能力，需要输出标准化测试方案",
  "session_id": "optional-session-id",
  "is_stream": false
}
```

返回体示例：

```json
{
  "message": "测试用例生成完成",
  "session_id": "xxx",
  "result_json": "...",
  "result_markdown": "..."
}
```

## 5. 本次实现如何满足需求描述

### 5.1 双步交叉验证与反思机制

已落地。

对应实现：

- 首轮标准化生成：`node_generate_primary_cases.py`
- 二次缺陷发散与反思：`node_leakage_review.py`
- Self-Reflection 字段化输出：`schemas.py` + Prompt 约束

### 5.2 Redis 多轮对话与 TTL 清理

已落地。

对应实现：

- `redis_history_utils.py`
- `redis_config.py`

说明：

- 默认 10 轮窗口
- 默认 TTL 3600 秒
- Redis 异常时自动降级为内存态，便于本地开发

### 5.3 严格 JSON 输出约束

已落地。

对应实现：

- `testcase_primary_generation.prompt`
- `testcase_leakage_review.prompt`
- `testcase_json_repair.prompt`
- `node_json_guard.py`
- `schemas.py`

### 5.4 防漏测自动补全

已落地。

对应实现：

- 缺陷知识检索：`node_search_test_knowledge.py`
- 缺陷模式补全：`node_leakage_review.py`

逻辑要点：

- 先生成主流程
- 再根据历史缺陷模式自动派生异常用例
- 通过 `missing_risk_scenarios` 和 `review_checklist` 输出显式漏测清单

## 6. 配置项说明

建议新增或确认以下环境变量：

```env
OPENAI_API_KEY=
OPENAI_BASE_URL=
LLM_DEFAULT_MODEL=
LLM_DEFAULT_TEMPERATURE=0.2

REDIS_URL=redis://127.0.0.1:6379/0
REDIS_KEY_PREFIX=testcase-agent
REDIS_SESSION_TTL_SECONDS=3600
REDIS_SESSION_WINDOW_ROUNDS=10

MILVUS_URL=
TESTCASE_STANDARDS_COLLECTION=testcase_standards
TESTCASE_DEFECTS_COLLECTION=testcase_defects
```

说明：

- `TESTCASE_STANDARDS_COLLECTION` 用于存放测试规范、P0/P1 规则、检查清单。
- `TESTCASE_DEFECTS_COLLECTION` 用于存放历史缺陷、根因总结、复盘文档。

## 7. 推荐入库数据

为了让这个 Agent 真正发挥效果，建议把以下数据沉淀进 Milvus：

- 测试规范
  - P0/P1 标准
  - 通用测试设计模板
  - 边界值与异常值设计规则
  - 权限/兼容性/幂等性检查清单
- 历史缺陷
  - 线上事故复盘
  - 回归缺陷
  - 高频漏测点
  - 权限、并发、时间边界、缓存一致性等问题

## 8. 运行方式

### 8.1 启动服务

```bash
uvicorn app.query_process.api.query_service:app --host 127.0.0.1 --port 8001
```

### 8.2 执行结构校验测试

```bash
python test/06-testcase-agent-schema.py
```

### 8.3 执行 Redis 会话降级测试

```bash
python test/07-redis-history-fallback.py
```

## 9. 后续可继续增强的方向

建议继续升级的点：

1. 将测试用例导出为 Excel、XMind 或测试管理平台格式。
2. 增加“需求变更对比”能力，自动识别回归测试范围。
3. 接 Jira、禅道、Tapd，把历史缺陷自动向量化入库。
4. 增加领域插件，如支付、审批、风控、库存、账号权限等行业模板。
5. 增加“风险评分器”，根据缺陷密度和业务关键度自动调整 P0/P1 比重。

## 10. 结论

本次改造不是简单把问答系统换个 Prompt，而是把原项目升级为一个更接近测试工程实际生产链路的 Agent：

- 有需求解析
- 有知识检索
- 有标准化结构输出
- 有历史缺陷反向补全
- 有会话管理
- 有严格 JSON 约束
- 有可继续追问的工程文档

因此，后续无论你要继续问：

- 为什么这样拆节点
- 为什么 Redis 要做滑动窗口
- 为什么 Self-Reflection 要字段化
- 为什么先主流程再防漏测补全
- Milvus 检索为什么这样设计

都可以直接基于这份实现继续展开。
