import sys
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parents[1]))

from app.clients.redis_history_utils import append_message, clear_history, get_recent_messages


if __name__ == "__main__":
    session_id = "demo-session"
    clear_history(session_id)
    append_message(session_id, "user", "用户要求：新增审批撤回测试")
    append_message(session_id, "assistant", "已生成测试方案")
    items = get_recent_messages(session_id, limit=10)
    print(f"history count={len(items)}")
    print(items)
