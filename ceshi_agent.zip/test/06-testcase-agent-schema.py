import sys
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parents[1]))

from app.testcase_agent.schemas import TestCaseAgentResponse


sample_payload = {
    "requirement_summary": "审批流程新增撤回能力",
    "rewritten_requirement": "针对审批流程新增撤回能力输出标准化测试方案",
    "standardized_cases": [
        {
            "case_id": "TC-P0-001",
            "title": "撤回主流程",
            "objective": "验证发起人可撤回待审批单据",
            "preconditions": ["已存在待审批单据"],
            "test_data": ["正常审批单据"],
            "steps": [
                {"step_no": 1, "action": "发起人点击撤回", "expected_result": "系统弹出确认框"},
                {"step_no": 2, "action": "确认撤回", "expected_result": "单据状态变为已撤回"},
            ],
            "priority": "P0",
            "case_type": "positive",
            "coverage_tags": ["审批", "主流程"],
            "risk_source": "schema-test",
        }
    ],
    "missing_risk_scenarios": ["并发撤回", "权限切换"],
    "review_checklist": ["覆盖 P0 主流程", "覆盖权限与状态校验"],
    "self_reflection": {
        "coverage_gaps_checked": ["权限", "并发"],
        "supplement_strategy": ["后续补充异常撤回"],
        "linked_defect_patterns": ["重复点击导致状态错乱"],
        "confidence": "high",
    },
}


if __name__ == "__main__":
    result = TestCaseAgentResponse.model_validate(sample_payload)
    print("schema ok")
    print(result.model_dump_json(indent=2))
