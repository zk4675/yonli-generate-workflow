# 基于Agent的测试用例标准化与防漏测智能体

这是一个面向测试工程师的测试辅助 Agent。它围绕“需求理解 -> 规范检索 -> 首轮生成 -> 防漏测反思 -> 严格 JSON 输出”这条链路，帮助测试人员快速产出高质量、标准化的测试方案。

## 核心能力

- 自动解析测试需求、用户故事和业务变更说明
- 检索测试规范库与历史缺陷库，做双步交叉验证
- 输出结构化测试用例，包含优先级、类型、步骤、预期结果和风险来源
- 结合历史缺陷自动补全边界、异常和高风险场景
- 使用 Redis 维护多轮会话，支持 10 轮滑动窗口和 TTL 清理
- 提供网页界面，可直接在浏览器中使用智能体

## 目录说明

- [app](app)
  - 服务端代码与 Agent 主链路
- [prompts](prompts)
  - Prompt 模板
- [doc/knowledge_base](doc/knowledge_base)
  - 默认测试规范库与历史缺陷库
- [doc/基于Agent的测试用例标准化与防漏测智能体技术说明.md](doc/基于Agent的测试用例标准化与防漏测智能体技术说明.md)
  - 技术设计说明
- [doc/项目使用说明.md](doc/项目使用说明.md)
  - 使用方法与前端操作说明
- [test](test)
  - 基础测试脚本

## 环境准备

1. 安装 Python 3.11+
2. 安装项目依赖
3. 配置环境变量

可参考 [.env.example](.env.example)：

```env
OPENAI_API_KEY=your_api_key
OPENAI_BASE_URL=https://your-openai-compatible-endpoint/v1
LLM_DEFAULT_MODEL=qwen3-32b
LLM_DEFAULT_TEMPERATURE=0.2

REDIS_URL=redis://127.0.0.1:6379/0
REDIS_KEY_PREFIX=testcase-agent
REDIS_SESSION_TTL_SECONDS=3600
REDIS_SESSION_WINDOW_ROUNDS=10

MILVUS_URL=http://127.0.0.1:19530
TESTCASE_STANDARDS_COLLECTION=testcase_standards
TESTCASE_DEFECTS_COLLECTION=testcase_defects
```

## 启动方式

### 1. 启动服务

```bash
uvicorn app.query_process.api.query_service:app --host 127.0.0.1 --port 8001
```

### 2. 打开网页

服务启动后，浏览器访问：

- `http://127.0.0.1:8001/chat.html`

## 使用方法

### 网页端

1. 在需求输入框中粘贴业务需求、用户故事或测试目标。
2. 点击“生成方案”。
3. 页面会显示：
   - 需求摘要
   - 标准化测试用例
   - 防漏测场景
   - 审查清单
   - 原始 JSON 结果
4. 如需保留上下文，可继续在同一会话中补充追问。

### API 调用

`POST /testcase/generate`

请求体：

```json
{
  "requirement": "审批流程新增撤回能力，需要输出标准化测试方案和防漏测场景",
  "session_id": "optional-session-id",
  "is_stream": false
}
```

返回示例：

```json
{
  "message": "测试用例生成完成",
  "session_id": "xxx",
  "result_json": "{...}",
  "result_markdown": "# 测试方案摘要 ..."
}
```

### 流式模式

如果 `is_stream=true`，先调用生成接口，再连接：

- `GET /stream/{session_id}`

流式事件会返回进度和最终结果。

## 知识库说明

当前项目支持两套知识来源：

1. Milvus 向量知识库
   - `TESTCASE_STANDARDS_COLLECTION`
   - `TESTCASE_DEFECTS_COLLECTION`
2. 本地 JSON 回退知识库
   - [testcase_standards.json](doc/knowledge_base/testcase_standards.json)
   - [historical_defects.json](doc/knowledge_base/historical_defects.json)

如果 Milvus 未配置，系统会自动使用本地知识资源，确保基本能力可用。

## Prompt 说明

核心 Prompt：

- `testcase_intent_parse.prompt`
- `testcase_primary_generation.prompt`
- `testcase_leakage_review.prompt`
- `testcase_json_repair.prompt`

它们分别负责：

- 需求改写与意图解析
- 首轮标准化测试方案生成
- 历史缺陷驱动的防漏测反思
- JSON 格式修复

## 基础验证

可以运行以下脚本做基础校验：

```bash
python test/06-testcase-agent-schema.py
python test/07-redis-history-fallback.py
```

## 适合继续增强的方向

- 导出 Excel、XMind、Markdown 报告
- 接 Jira / 禅道 / TAPD 自动沉淀缺陷知识
- 引入业务域插件，如支付、审批、库存、会员、风控
- 增加需求差异对比和回归范围识别
